# pySERRF
Python implementation of the Systematic Error Removal Using Random Forest algorithm
